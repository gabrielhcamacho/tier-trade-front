'use client';

import { useEffect, useId, useState, type InputHTMLAttributes, type ReactNode } from 'react';
import { formatAutomaticDecimalInput, normalizeDecimalInput } from './decimal';

type FieldProps = {
  label: string;
  children: ReactNode;
  hint?: string;
  error?: string;
  required?: boolean;
  source?: string;
  className?: string;
};

export function Field({ label, children, hint, error, required, source, className }: FieldProps) {
  return (
    <label className={`tt-field ${error ? 'tt-field--error' : ''} ${className ?? ''}`}>
      <span className="tt-field__label">
        <span>{label}{required ? <b aria-hidden="true"> *</b> : null}</span>
        {source ? <small>{source}</small> : null}
      </span>
      {children}
      {error ? <span className="tt-field__message" role="alert">{error}</span> : null}
      {!error && hint ? <span className="tt-field__hint">{hint}</span> : null}
    </label>
  );
}

type DecimalFieldProps = Omit<InputHTMLAttributes<HTMLInputElement>, 'defaultValue' | 'name' | 'type' | 'value'> & {
  name: string;
  label: string;
  defaultValue?: string;
  prefix?: string;
  suffix?: string;
  hint?: string;
  error?: string;
  source?: string;
  fractionDigits?: number;
  emptyWhenZero?: boolean;
};

function formatDecimal(value: string, fractionDigits: number): string {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return '';
  return new Intl.NumberFormat('pt-BR', {
    minimumFractionDigits: fractionDigits,
    maximumFractionDigits: fractionDigits,
  }).format(numeric);
}

function sanitizeDecimalTyping(value: string, fractionDigits: number): string {
  const cleaned = value.replace(/[^\d,.]/g, '');
  if (fractionDigits === 0) return cleaned.replace(/[,.]/g, '');
  const separatorIndex = Math.max(cleaned.lastIndexOf(','), cleaned.lastIndexOf('.'));
  if (separatorIndex < 0) return cleaned;
  const integer = cleaned.slice(0, separatorIndex).replace(/[,.]/g, '');
  const fraction = cleaned.slice(separatorIndex + 1).replace(/[,.]/g, '').slice(0, fractionDigits);
  return `${integer || '0'},${fraction}`;
}

export function DecimalField({
  name,
  label,
  defaultValue = '0',
  prefix,
  suffix,
  hint,
  error,
  source,
  fractionDigits = 2,
  emptyWhenZero = true,
  required,
  disabled,
  onBlur,
  onChange,
  onFocus,
  onKeyDown,
  placeholder,
  ...inputProps
}: DecimalFieldProps) {
  const inputId = useId();
  const parsedDefault = normalizeDecimalInput(defaultValue, fractionDigits);
  const initialValue = emptyWhenZero && Number(parsedDefault) === 0 ? '' : (parsedDefault ?? '');
  const [display, setDisplay] = useState(initialValue ? formatDecimal(initialValue, fractionDigits) : '');

  useEffect(() => {
    const nextDefault = normalizeDecimalInput(defaultValue, fractionDigits);
    const nextCanonical = emptyWhenZero && Number(nextDefault) === 0 ? '' : (nextDefault ?? '');
    setDisplay(nextCanonical ? formatDecimal(nextCanonical, fractionDigits) : '');
  }, [defaultValue, emptyWhenZero, fractionDigits]);

  return (
    <Field label={label} hint={hint} error={error} source={source} required={required}>
      <span className={`tt-decimal ${disabled ? 'tt-decimal--disabled' : ''}`}>
        {prefix ? <span className="tt-decimal__affix">{prefix}</span> : null}
        <input
          {...inputProps}
          id={inputId}
          name={name}
          inputMode={fractionDigits > 0 ? 'numeric' : 'decimal'}
          autoComplete="off"
          value={display}
          placeholder={placeholder ?? formatDecimal('0', fractionDigits)}
          required={required}
          disabled={disabled}
          aria-invalid={Boolean(error)}
          onFocus={(event) => {
            event.currentTarget.select();
            onFocus?.(event);
          }}
          onKeyDown={(event) => {
            onKeyDown?.(event);
            if (event.defaultPrevented || fractionDigits === 0 || !['Backspace', 'Delete'].includes(event.key)) return;
            event.preventDefault();
            const currentDigits = display.replace(/\D/g, '');
            const allSelected = event.currentTarget.selectionStart === 0
              && event.currentTarget.selectionEnd === event.currentTarget.value.length;
            setDisplay(allSelected ? '' : formatAutomaticDecimalInput(currentDigits.slice(0, -1), fractionDigits));
          }}
          onChange={(event) => {
            const nextDisplay = fractionDigits > 0
              ? formatAutomaticDecimalInput(event.currentTarget.value, fractionDigits)
              : sanitizeDecimalTyping(event.currentTarget.value, fractionDigits);
            setDisplay(nextDisplay);
            onChange?.(event);
          }}
          onBlur={(event) => {
            const nextCanonical = normalizeDecimalInput(event.currentTarget.value, fractionDigits);
            setDisplay(nextCanonical ? formatDecimal(nextCanonical, fractionDigits) : '');
            onBlur?.(event);
          }}
        />
        {suffix ? <span className="tt-decimal__affix tt-decimal__affix--suffix">{suffix}</span> : null}
      </span>
    </Field>
  );
}

export function FormSection({ number, title, hint, children }: {
  number: number;
  title: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <section className="tt-form-section">
      <header>
        <span>{number}</span>
        <h2>{title}</h2>
        {hint ? <p>{hint}</p> : null}
      </header>
      <div className="tt-form-section__grid">{children}</div>
    </section>
  );
}
