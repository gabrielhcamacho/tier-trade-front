export function normalizeDecimalInput(value: string, fractionDigits = 2): string | null {
  const cleaned = value.trim().replace(/\s/g, '').replace(/[^\d,.]/g, '');
  if (!cleaned) return null;
  let normalized: string;
  if (cleaned.includes(',')) {
    normalized = cleaned.replace(/\./g, '').replace(',', '.');
  } else {
    const pieces = cleaned.split('.');
    normalized = pieces.length > 2 ? `${pieces.slice(0, -1).join('')}.${pieces.at(-1)}` : cleaned;
  }
  const numeric = Number(normalized);
  if (!Number.isFinite(numeric) || numeric < 0) return null;
  return numeric.toFixed(fractionDigits);
}

export function formatAutomaticDecimalInput(value: string, fractionDigits = 2): string {
  const digits = value.replace(/\D/g, '');
  if (!digits) return '';
  if (fractionDigits === 0) return digits;

  const padded = digits.padStart(fractionDigits + 1, '0');
  const fraction = padded.slice(-fractionDigits);
  const ungroupedInteger = padded.slice(0, -fractionDigits).replace(/^0+(?=\d)/, '') || '0';
  const integer = ungroupedInteger.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return `${integer},${fraction}`;
}
