import type { HTMLAttributes } from 'react';

export function Status({ tone = 'neutral', ...props }: HTMLAttributes<HTMLSpanElement> & {
  tone?: 'neutral' | 'positive' | 'warning' | 'info' | 'critical';
}) {
  return <span className="tt-status" data-tone={tone} {...props} />;
}
