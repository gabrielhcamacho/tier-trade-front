import type { ButtonHTMLAttributes } from 'react';

export function Button({ variant = 'primary', size = 'md', className, ...props }: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: 'primary' | 'secondary' | 'tertiary' | 'danger';
  size?: 'sm' | 'md';
}) {
  return <button className={`tt-button ${className ?? ''}`} data-variant={variant} data-size={size} {...props} />;
}
