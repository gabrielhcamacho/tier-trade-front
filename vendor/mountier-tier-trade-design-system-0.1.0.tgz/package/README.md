# Tier Trade Design System

Fonte de componentes mantíveis derivada do pacote visual `mountier-trading-ds-v2` e da composição do protótipo. A alteração aprovada está consolidada: **Geist Sans** é a fonte de interface e **Geist Mono** é reservada para IDs e valores tabulares. Elms Sans não faz parte deste repositório.

Os tokens mantêm a sobriedade, densidade e linguagem operacional do material visual; novos componentes devem nascer de necessidades reais das vertical slices.
